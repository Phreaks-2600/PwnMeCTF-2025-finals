#!/bin/bash

python app.py &

node server.js &

wait
